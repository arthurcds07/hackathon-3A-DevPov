# hackathon-3A-DevPov
Atividade Ensino Médio Senac com o Tema 3: Simulador de Vida Dev
