CREATE DATABASE devsim;

USE devsim;


CREATE TABLE progresso (

  id VARCHAR(50) PRIMARY KEY,  
  money INT DEFAULT 10,       
  xp INT DEFAULT 5             

);
 
SELECT * from progresso;